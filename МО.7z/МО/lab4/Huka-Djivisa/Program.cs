﻿using System;

namespace Huka_Djivisa
{
    class Program
    {
        static void Main(string[] args)
        {
            var func = new Huka_Djivisa(5,
                new[] {
                    5.0 /2, 10.0/2, 4.0/2, 2.0/2, 20.0/2
                },
                 new[] {
                    500 * 20.0,
                    100 * 10,
                    200 * 5,
                    150 * 3,
                    400 * 7

                } );

            func.MinimazeFunction();
            
            Console.WriteLine("Done!");
            Console.ReadKey(true);
        }
    }
}
